"""
Medgent Setup Wizard
Guides you through the complete Medgent configuration.
Designed to be so easy a 10-year-old can do it.
"""

import json, os, sys, time
from pathlib import Path

GREEN  = "\033[92m"
YELLOW = "\033[93m"
BLUE   = "\033[94m"
RED    = "\033[91m"
BOLD   = "\033[1m"
RESET  = "\033[0m"
CYAN   = "\033[96m"

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def hdr(text):
    print(f"\n{BOLD}{GREEN}{'─'*50}{RESET}")
    print(f"{BOLD}{GREEN}  {text}{RESET}")
    print(f"{BOLD}{GREEN}{'─'*50}{RESET}\n")

def ask(prompt, default="", required=True):
    while True:
        val = input(f"  {BLUE}→{RESET} {prompt}: {CYAN}").strip()
        print(RESET, end="")
        if val:
            return val
        if default:
            return default
        if not required:
            return ""
        print(f"  {RED}⚠  This field is required. Please enter a value.{RESET}")

def pick(prompt, options):
    print(f"  {BLUE}→{RESET} {prompt}")
    for i, (label, _) in enumerate(options, 1):
        print(f"     {CYAN}{i}.{RESET} {label}")
    while True:
        try:
            choice = int(input(f"  {BLUE}Enter number (1-{len(options)}): {CYAN}").strip())
            print(RESET, end="")
            if 1 <= choice <= len(options):
                return options[choice - 1][1]
        except (ValueError, KeyboardInterrupt):
            pass
        print(f"  {RED}⚠  Please enter a number between 1 and {len(options)}{RESET}")

def separator():
    print(f"\n  {GREEN}{'·' * 44}{RESET}\n")


def main():
    clear()
    print(f"""
{GREEN}{BOLD}
  ╔══════════════════════════════════════════╗
  ║   🏥  MEDGENT SETUP WIZARD              ║
  ║   Your Personal AI Health Manager       ║
  ║   Open Source · MIT Licence             ║
  ╚══════════════════════════════════════════╝
{RESET}
  Welcome! This wizard takes about 5 minutes.
  You'll configure your AI brain, connect your
  messaging app, and set your health profile.

  {YELLOW}Press Enter to start...{RESET}""")
    input()

    config = {}
    Path("config").mkdir(exist_ok=True)
    Path("data").mkdir(exist_ok=True)

    # ─────────────────────────────────────────
    # STEP 1: Choose AI Provider
    # ─────────────────────────────────────────
    clear()
    hdr("STEP 1 of 5 — Choose Your AI Brain 🧠")
    print("""  Pick the AI that will power your health coach.
  Don't worry — you can change this anytime.\n""")

    print(f"  {YELLOW}💡 Recommendation for beginners: Claude (option 1){RESET}")
    print(f"  {YELLOW}   It has the best health understanding + $5 free credit{RESET}\n")

    ai_options = [
        ("Claude (Anthropic) — Best for health · ~$0.003/msg · $5 free credit",   "claude"),
        ("ChatGPT (OpenAI) — Most popular · ~$0.002/msg · free trial",             "openai"),
        ("Gemini (Google) — Free tier available · Fast",                           "gemini"),
        ("Mistral AI — European · Privacy-focused · Free tier",                    "mistral"),
        ("Llama (Local) — 100% FREE · Runs offline · No API key needed",           "llama"),
        ("DeepSeek — Very affordable · Powerful",                                  "deepseek"),
    ]
    config["ai_provider"] = pick("Which AI do you want to use?", ai_options)

    separator()

    if config["ai_provider"] != "llama":
        key_urls = {
            "claude":   "https://console.anthropic.com  →  API Keys  →  New Key",
            "openai":   "https://platform.openai.com    →  API Keys  →  Create new",
            "gemini":   "https://aistudio.google.com    →  Get API Key (FREE, no card)",
            "mistral":  "https://console.mistral.ai     →  API Keys  →  New Key",
            "deepseek": "https://platform.deepseek.com  →  API Keys  →  Create",
        }
        print(f"  {GREEN}✓ Where to get your free API key:{RESET}")
        print(f"  {CYAN}{key_urls.get(config['ai_provider'], '')}{RESET}\n")
        print(f"  {YELLOW}Open that URL, create a free account, copy the key, paste it below.{RESET}\n")
        config["api_key"] = ask("Paste your API key here (it starts with sk-...)")
        print(f"\n  {GREEN}✅ API key saved securely!{RESET}")
    else:
        print(f"""
  {GREEN}✅ Llama (Local) selected — completely FREE!{RESET}

  {YELLOW}You need Ollama installed to run Llama locally:{RESET}
  1. Go to https://ollama.ai and download Ollama (free)
  2. Run: {CYAN}ollama pull llama3{RESET}
  3. Ollama runs in the background — Medgent connects automatically
        """)
        config["api_key"] = "local"

    input(f"\n  {YELLOW}Press Enter to continue...{RESET}")

    # ─────────────────────────────────────────
    # STEP 2: Choose Chat Channel
    # ─────────────────────────────────────────
    clear()
    hdr("STEP 2 of 5 — Connect Your Chat App 💬")
    print("""  Where do you want to receive Medgent messages?
  Pick the app you use most.\n""")

    channel_options = [
        ("Telegram — Easiest! Free forever, bot ready in 60s",        "telegram"),
        ("WhatsApp — Via Twilio (free $15 credit to start)",           "whatsapp"),
        ("Discord — For Discord servers or DMs (free)",                "discord"),
        ("Signal — Privacy-first messaging (free)",                    "signal"),
        ("Slack — For workplace health management (free)",             "slack"),
        ("Facebook Messenger — Via Meta Webhooks (free)",              "messenger"),
        ("SMS/iMessage — Works on any phone via Twilio SMS",           "sms"),
        ("Multiple channels — Pick more than one",                     "multi"),
        ("Web browser only — No messaging app needed",                 "web"),
    ]
    config["channel"] = pick("Which messaging app?", channel_options)

    separator()

    # Handle multi-channel selection
    if config["channel"] == "multi":
        print(f"\n  {YELLOW}Select which channels to enable (comma-separated numbers):{RESET}")
        print(f"  1=Telegram  2=WhatsApp  3=Discord  4=Signal  5=Slack  6=Messenger  7=SMS")
        choices = input(f"  {BLUE}→ Enter numbers (e.g. 1,2): {CYAN}").strip()
        num_map = {"1":"telegram","2":"whatsapp","3":"discord","4":"signal","5":"slack","6":"messenger","7":"sms"}
        selected = [num_map[c.strip()] for c in choices.split(",") if c.strip() in num_map]
        config["channel"] = ",".join(selected) if selected else "telegram"
        config["enabled_channels"] = selected if selected else ["telegram"]
    else:
        config["enabled_channels"] = [config["channel"]]

    if "telegram" in config.get("enabled_channels", [config["channel"]]):
        print(f"""
  {BOLD}Setting up Telegram:{RESET}

  {YELLOW}1.{RESET} Open Telegram and search for {CYAN}@BotFather{RESET}
  {YELLOW}2.{RESET} Send the message: {CYAN}/newbot{RESET}
  {YELLOW}3.{RESET} BotFather will ask for a name → type: {CYAN}Medgent Health Coach{RESET}
  {YELLOW}4.{RESET} Then a username → type: {CYAN}MyMedgentBot{RESET} (pick anything ending in "bot")
  {YELLOW}5.{RESET} BotFather gives you a token — copy it and paste below
        """)
        config["telegram_token"] = ask("Paste your Telegram Bot Token here")
        print(f"\n  {GREEN}✅ Telegram connected!{RESET}")
        print(f"  Search for your bot on Telegram and send /start to test it.")

    if config["channel"] in ("whatsapp", "both"):
        print(f"""
  {BOLD}Setting up WhatsApp:{RESET}

  {YELLOW}1.{RESET} Go to {CYAN}https://twilio.com{RESET} and create a free account
  {YELLOW}2.{RESET} In Twilio Console → Messaging → Try it out → WhatsApp Sandbox
  {YELLOW}3.{RESET} Scan the QR code with your phone WhatsApp
  {YELLOW}4.{RESET} Copy your Account SID, Auth Token, and WhatsApp number from Twilio
        """)
        config["twilio_account_sid"]    = ask("Twilio Account SID")
        config["twilio_auth_token"]     = ask("Twilio Auth Token")
        config["twilio_whatsapp_number"]= ask("Twilio WhatsApp number (e.g. whatsapp:+14155238886)")
        config["your_whatsapp_number"]  = ask("Your WhatsApp number (e.g. whatsapp:+1234567890)")
        print(f"\n  {GREEN}✅ WhatsApp connected!{RESET}")

    input(f"\n  {YELLOW}Press Enter to continue...{RESET}")

    # ─────────────────────────────────────────
    # STEP 3: Health Profile
    # ─────────────────────────────────────────
    clear()
    hdr("STEP 3 of 5 — Your Health Profile 👤")
    print("""  Tell Medgent about yourself so it can
  personalise every response for your needs.\n""")

    profile = {}
    profile["name"]       = ask("Your first name")
    profile["age"]        = ask("Your age")
    profile["gender"]     = pick("Your gender", [
        ("Male", "Male"), ("Female", "Female"), ("Prefer not to say", "Other")
    ])

    print(f"\n  {YELLOW}💡 Common conditions: Type 2 Diabetes, Hypertension, Asthma,{RESET}")
    print(f"  {YELLOW}   Heart Disease, IBS, Thyroid, PCOS, Arthritis, or type your own{RESET}\n")
    profile["condition"]  = ask("Your health condition (or 'General Wellness')")
    profile["height"]     = float(ask("Height in cm (e.g. 170)"))
    profile["weight"]     = float(ask("Current weight in kg (e.g. 75)"))
    profile["goal_weight"]= ask("Goal weight in kg (e.g. 68)", default=str(profile["weight"]))
    profile["medications"]= ask("Current medications (or press Enter to skip)", required=False) or "None"
    profile["diet_restrictions"] = ask("Diet restrictions (e.g. vegetarian, no nuts, or press Enter)", required=False) or "None"
    profile["calorie_goal"] = int(ask("Daily calorie goal (e.g. 1800)", default="1800"))

    goal_options = [
        ("Manage my condition better",   "Manage condition"),
        ("Lose weight safely",           "Lose weight"),
        ("Build strength & fitness",     "Build strength"),
        ("Improve energy levels",        "Improve energy"),
        ("Better sleep & recovery",      "Better sleep"),
    ]
    profile["health_goal"] = pick("Your primary health goal", goal_options)
    config["user_profile"] = profile
    print(f"\n  {GREEN}✅ Health profile saved!{RESET}")
    input(f"\n  {YELLOW}Press Enter to continue...{RESET}")

    # ─────────────────────────────────────────
    # STEP 4: Reminder Schedule
    # ─────────────────────────────────────────
    clear()
    hdr("STEP 4 of 5 — Set Your Schedule ⏰")
    print("""  Medgent will send you automatic health updates.
  Choose when you want them.\n""")

    config["morning_briefing_time"] = ask("Morning briefing time (24hr, e.g. 07:30)", default="07:30")
    config["timezone"] = ask("Your timezone (e.g. Asia/Kolkata, America/New_York, Europe/London)", default="UTC")
    print(f"\n  {GREEN}✅ Schedule saved!{RESET}")

    # Medication reminders
    if profile["medications"] != "None":
        print(f"\n  {YELLOW}💊 Setting up medication reminders for: {profile['medications']}{RESET}")
        med_time_1 = ask("First medication time (e.g. 08:00)", default="08:00")
        med_time_2 = ask("Second medication time (or press Enter if once daily)", required=False) or ""
        config["med_reminder_times"] = [med_time_1]
        if med_time_2:
            config["med_reminder_times"].append(med_time_2)
        print(f"  {GREEN}✅ Medication reminders set!{RESET}")

    input(f"\n  {YELLOW}Press Enter to continue...{RESET}")

    # ─────────────────────────────────────────
    # STEP 5: Save & Launch
    # ─────────────────────────────────────────
    clear()
    hdr("STEP 5 of 5 — Saving & Launching 🚀")

    with open("config/settings.json", "w") as f:
        json.dump(config, f, indent=2)
    print(f"  {GREEN}✅ Configuration saved to config/settings.json{RESET}\n")

    # ─────────────────────────────────────────
    # FINAL INSTRUCTIONS
    # ─────────────────────────────────────────
    clear()
    print(f"""
{GREEN}{BOLD}
  ╔══════════════════════════════════════════╗
  ║   🎉  MEDGENT IS READY!                 ║
  ╚══════════════════════════════════════════╝
{RESET}
  {BOLD}How to start Medgent:{RESET}
""")

    # Handle multi-channel selection
    if config["channel"] == "multi":
        print(f"\n  {YELLOW}Select which channels to enable (comma-separated numbers):{RESET}")
        print(f"  1=Telegram  2=WhatsApp  3=Discord  4=Signal  5=Slack  6=Messenger  7=SMS")
        choices = input(f"  {BLUE}→ Enter numbers (e.g. 1,2): {CYAN}").strip()
        num_map = {"1":"telegram","2":"whatsapp","3":"discord","4":"signal","5":"slack","6":"messenger","7":"sms"}
        selected = [num_map[c.strip()] for c in choices.split(",") if c.strip() in num_map]
        config["channel"] = ",".join(selected) if selected else "telegram"
        config["enabled_channels"] = selected if selected else ["telegram"]
    else:
        config["enabled_channels"] = [config["channel"]]

    if "telegram" in config.get("enabled_channels", [config["channel"]]):
        print(f"""  {BOLD}Telegram:{RESET}
  {CYAN}python channels/telegram_bot.py{RESET}
  → Then open Telegram and message your bot
""")
    if config["channel"] in ("whatsapp", "both"):
        print(f"""  {BOLD}WhatsApp:{RESET}
  {CYAN}python channels/whatsapp_bot.py{RESET}
  → Then set webhook URL in Twilio console
""")
    if config["channel"] == "web":
        print(f"""  {BOLD}Web Browser:{RESET}
  {CYAN}python channels/web_server.py{RESET}
  → Open http://localhost:5050 in your browser
""")

    print(f"""  {BOLD}To run 24/7 on a server, use:{RESET}
  {CYAN}bash scripts/start.sh{RESET}
  (uses screen/tmux to keep running after you disconnect)

  {YELLOW}⚕️  Medical Disclaimer:{RESET}
  Medgent is a wellness assistant only — not a substitute
  for medical advice. Always consult your doctor.

  {GREEN}GitHub: https://github.com/medgent/medgent{RESET}
  {GREEN}Docs:   https://medgent.ai/docs{RESET}

  {BOLD}Enjoy your AI health manager! 💚{RESET}
""")


if __name__ == "__main__":
    main()
