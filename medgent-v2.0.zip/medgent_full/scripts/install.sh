#!/bin/bash
# Medgent One-Click Installer
# curl -fsSL https://get.medgent.in | bash

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

clear
echo -e "${GREEN}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║   🏥  MEDGENT INSTALLER                  ║"
echo "  ║   Personal AI Health Manager             ║"
echo "  ║   www.medgent.in                         ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"

# Check/install Python
if ! command -v python3 &>/dev/null; then
    echo -e "${YELLOW}Installing Python...${NC}"
    apt-get install -y -q python3 python3-pip 2>/dev/null || yum install -y python3 python3-pip 2>/dev/null
fi
echo -e "${GREEN}✓ Python $(python3 --version 2>&1 | grep -oP '\d+\.\d+') ready${NC}"

# Check/install git
command -v git &>/dev/null || apt-get install -y -q git 2>/dev/null

# Download Medgent
if [ -d "medgent" ]; then
    echo -e "${CYAN}Updating existing Medgent...${NC}"
    cd medgent && git pull --quiet 2>/dev/null && cd ..
else
    echo -e "${YELLOW}Downloading Medgent from GitHub...${NC}"
    git clone --quiet https://github.com/medgent/medgent.git 2>/dev/null || {
        echo "Downloading ZIP instead..."
        curl -fsSL "https://github.com/medgent/medgent/raw/refs/heads/main/medgent-v1.0.zip" -o medgent.zip
        unzip -q medgent.zip && mv medgent-package medgent 2>/dev/null || true
        rm -f medgent.zip
    }
fi
cd medgent

# Create dirs
mkdir -p config data logs

# Install dependencies
echo -e "${YELLOW}Installing dependencies...${NC}"
python3 -m pip install -q -r requirements.txt 2>/dev/null
chmod +x scripts/*.sh 2>/dev/null

echo ""
echo -e "${GREEN}${BOLD}✅ Medgent installed! Now run:${NC}"
echo -e "${CYAN}python3 setup.py${NC}"
echo ""
echo -e "${YELLOW}⚕️ Medgent is a wellness assistant only — not medical advice.${NC}"
