#!/bin/bash
for ch in telegram whatsapp discord signal slack messenger sms webhook web; do
    screen -S "medgent-$ch" -X quit 2>/dev/null
done
echo "✅ All Medgent bots stopped."
