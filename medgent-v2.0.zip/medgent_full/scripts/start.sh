#!/bin/bash
# Medgent — Universal Start Script
# Starts all configured chat channel bots

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║   🏥 Starting Medgent...                 ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""

if [ ! -f "config/settings.json" ]; then
    echo -e "${RED}❌ No config found. Run: python3 setup.py first${NC}"; exit 1
fi

# Read channel config
CHANNELS=$(python3 -c "
import json
c = json.load(open('config/settings.json'))
ch = c.get('enabled_channels', [c.get('channel','telegram')])
print(' '.join(ch) if isinstance(ch, list) else ch)
" 2>/dev/null)

echo -e "${CYAN}📡 Configured channels: ${CHANNELS}${NC}"
echo ""

# Install screen if needed
command -v screen &>/dev/null || apt-get install -y -q screen 2>/dev/null

# Kill existing sessions
for ch in telegram whatsapp discord signal slack messenger sms webhook; do
    screen -S "medgent-$ch" -X quit 2>/dev/null
done

mkdir -p logs

# Start each configured channel
start_channel() {
    local NAME=$1; local SCRIPT=$2; local PORT=$3
    if [ -f "channels/$SCRIPT" ]; then
        echo -e "${GREEN}🚀 Starting $NAME...${NC}"
        screen -dmS "medgent-$(echo $NAME | tr '[:upper:]' '[:lower:]')" \
            bash -c "cd $(pwd) && python3 channels/$SCRIPT 2>&1 | tee logs/$NAME.log"
        echo -e "${GREEN}   ✅ $NAME running${NC}${PORT:+ (port $PORT)}"
    fi
}

for CHANNEL in $CHANNELS; do
    case $CHANNEL in
        telegram)   start_channel "Telegram"   "telegram_bot.py" "" ;;
        whatsapp)   start_channel "WhatsApp"   "whatsapp_bot.py" "5000" ;;
        discord)    start_channel "Discord"    "discord_bot.py" "" ;;
        signal)     start_channel "Signal"     "signal_bot.py" "" ;;
        slack)      start_channel "Slack"      "slack_bot.py" "5002" ;;
        messenger)  start_channel "Messenger"  "messenger_bot.py" "5001" ;;
        sms)        start_channel "SMS"        "sms_bot.py" "5003" ;;
        webhook)    start_channel "Webhook"    "webhook_bot.py" "5004" ;;
        web)        start_channel "Web UI"     "web_server.py" "5050" ;;
    esac
done

echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║  ✅ Medgent is running!                      ║${NC}"
echo -e "${GREEN}${BOLD}║                                              ║${NC}"
echo -e "${GREEN}${BOLD}║  View logs:  screen -r medgent-telegram      ║${NC}"
echo -e "${GREEN}${BOLD}║  Stop all:   bash scripts/stop.sh            ║${NC}"
echo -e "${GREEN}${BOLD}║  Website:    www.medgent.in                  ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}⚕️  Medgent is a wellness assistant only.${NC}"
echo -e "${YELLOW}   Always consult your doctor for medical advice.${NC}"
echo ""
