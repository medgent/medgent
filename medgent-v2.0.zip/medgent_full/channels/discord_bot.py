"""
Medgent — Discord Bot Channel
Connects Medgent to a Discord server or DMs via discord.py

HOW TO SET UP (3 minutes):
1. Go to https://discord.com/developers/applications
2. Click "New Application" → name it "Medgent Health Coach"
3. Go to "Bot" tab → click "Add Bot" → copy the TOKEN
4. Under "Privileged Gateway Intents" → enable:
   ✅ Message Content Intent
5. Invite bot to your server:
   Go to OAuth2 → URL Generator → check "bot" + "Send Messages" + "Read Messages"
   Copy the URL → open it → add to your Discord server
6. Set discord_token in config/settings.json

⚕️ Medical Disclaimer: Medgent is a wellness assistant only.
   Always consult your doctor for medical advice.
"""

import asyncio, json, logging, sys
from pathlib import Path
import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO, format='%(asctime)s [Discord] %(message)s')
logger = logging.getLogger(__name__)

config  = json.loads(Path("config/settings.json").read_text())
TOKEN   = config.get("discord_token", "")
BOT_CHANNEL = config.get("discord_channel_name", "medgent-health")  # channel to listen in

bot_agent = MedgentBot()
NEW_SESSIONS = set()

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="/", intents=intents)


@bot.event
async def on_ready():
    logger.info(f"💜 Medgent Discord bot ready! Logged in as {bot.user}")
    logger.info(f"Listening in channels named: #{BOT_CHANNEL} or via DM")
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching, name="your health 🏥"
    ))


@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # Respond in DMs or in the designated health channel
    is_dm = isinstance(message.channel, discord.DMChannel)
    is_health_channel = hasattr(message.channel, 'name') and BOT_CHANNEL in message.channel.name

    if not (is_dm or is_health_channel or bot.user in message.mentions):
        return

    text = message.content.strip()
    # Remove bot mention from message
    text = text.replace(f'<@{bot.user.id}>', '').strip()
    if not text:
        return

    user_id = str(message.author.id)
    is_new = user_id not in NEW_SESSIONS

    async with message.channel.typing():
        try:
            response = await bot_agent.process_message(text, is_new_session=is_new)
            NEW_SESSIONS.add(user_id)

            # Discord has 2000 char limit per message
            chunks = [response[i:i+1900] for i in range(0, len(response), 1900)]
            for chunk in chunks:
                # Format for Discord: **bold** already works, convert *italic*
                discord_text = chunk.replace('*', '**').replace('****', '**')
                await message.reply(discord_text)
                if len(chunks) > 1:
                    await asyncio.sleep(0.3)

        except Exception as e:
            logger.error(f"Discord error: {e}")
            await message.reply("⚠️ I had trouble responding. Please try again.")

    await bot.process_commands(message)


@bot.command(name="start")
async def start_cmd(ctx):
    """!start — Begin your Medgent health journey"""
    user_id = str(ctx.author.id)
    NEW_SESSIONS.add(user_id)
    name = ctx.author.display_name
    await ctx.reply(
        f"👋 Hello **{name}**! I'm Medgent — your personal AI health manager.\n\n"
        f"{DISCLAIMER}\n\n"
        f"Use `/setup` to configure your health profile, or just ask me anything!\n\n"
        f"Try: *\"What should I eat today?\"* or *\"Give me a workout plan\"*"
    )


@bot.command(name="status")
async def status_cmd(ctx):
    """!status — Check Medgent status"""
    p = bot_agent.user_profile
    await ctx.reply(
        f"📊 **Medgent Status**\n"
        f"👤 {p.get('name','Not set')} · {p.get('condition','No condition set')}\n"
        f"🤖 AI: {bot_agent.ai_provider.upper()}\n"
        f"✅ Online and monitoring your health!\n\n"
        f"⚕️ *Wellness assistant only — consult your doctor for medical advice.*"
    )


if __name__ == "__main__":
    if not TOKEN:
        print("❌ No discord_token found in config/settings.json")
        print("Get your bot token from: https://discord.com/developers/applications")
        sys.exit(1)
    logger.info("Starting Medgent Discord bot...")
    bot.run(TOKEN)
