"""
Medgent — Slack Bot Channel
Connects Medgent to Slack workspaces via Slack Bolt SDK

HOW TO SET UP (10 minutes):
1. Go to https://api.slack.com/apps → Create New App → "From scratch"
2. Name: "Medgent Health Coach"
3. Under "OAuth & Permissions":
   - Add Bot Token Scopes: chat:write, im:history, im:read, im:write, users:read
4. Under "Event Subscriptions":
   - Enable Events → Request URL: https://yourdomain.com/slack/events
   - Subscribe to bot events: message.im (direct messages)
5. Under "App Home": enable "Allow users to send Slash commands and messages from messages tab"
6. Install App to Workspace → copy Bot User OAuth Token
7. Copy Signing Secret from Basic Information
8. Set in config/settings.json:
   - slack_bot_token: xoxb-your-token
   - slack_signing_secret: your-signing-secret

⚕️ Medical Disclaimer: Medgent is a wellness assistant only.
   Always consult your doctor for medical advice.
"""

import asyncio, json, logging, sys
from pathlib import Path
from slack_bolt import App
from slack_bolt.adapter.flask import SlackRequestHandler
from flask import Flask, request

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO, format='%(asctime)s [Slack] %(message)s')
logger = logging.getLogger(__name__)

config         = json.loads(Path("config/settings.json").read_text())
BOT_TOKEN      = config.get("slack_bot_token", "")
SIGNING_SECRET = config.get("slack_signing_secret", "")

if not BOT_TOKEN:
    print("❌ No slack_bot_token in config/settings.json")
    print("Get yours from: https://api.slack.com/apps")
    sys.exit(1)

slack_app = App(token=BOT_TOKEN, signing_secret=SIGNING_SECRET)
flask_app = Flask(__name__)
handler   = SlackRequestHandler(slack_app)
bot       = MedgentBot()
NEW_SESSIONS = set()


@slack_app.message("")
def handle_dm(message, say):
    """Handle all direct messages to Medgent."""
    user_id = message.get("user", "")
    text    = message.get("text", "").strip()
    if not text or not user_id:
        return

    is_new = user_id not in NEW_SESSIONS

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        response = loop.run_until_complete(
            bot.process_message(text, is_new_session=is_new)
        )
        NEW_SESSIONS.add(user_id)

        # Format for Slack: convert markdown-style bold
        slack_response = response.replace('**', '*')

        # Split at 3000 chars if needed
        if len(slack_response) > 2900:
            chunks = [slack_response[i:i+2900] for i in range(0, len(slack_response), 2900)]
            for chunk in chunks:
                say(chunk)
        else:
            say(slack_response)

    except Exception as e:
        logger.error(f"Slack error: {e}")
        say(f"⚠️ I had trouble responding. Please try again.\n\n{DISCLAIMER}")
    finally:
        loop.close()


@flask_app.route("/slack/events", methods=["POST"])
def slack_events():
    return handler.handle(request)


if __name__ == "__main__":
    logger.info("🟦 Medgent Slack bot running on port 5002")
    logger.info("Set your Slack Event Subscriptions URL to: https://YOUR-DOMAIN/slack/events")
    flask_app.run(host="0.0.0.0", port=5002, debug=False)
