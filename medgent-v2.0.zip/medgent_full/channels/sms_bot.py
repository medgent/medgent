"""
Medgent — SMS Bot Channel (via Twilio SMS)
Also works as an iMessage fallback — when iPhone users text your Twilio number,
Apple's iMessage routes to SMS which Twilio handles.

HOW TO SET UP (5 minutes):
1. Create free Twilio account at https://twilio.com/try-twilio
   ($15.50 free credit included)
2. In Twilio Console → Phone Numbers → Get a number ($1/month)
3. In the number settings → Messaging → "A message comes in" webhook:
   Set to: https://YOUR-DOMAIN.com/webhook/sms  (POST)
4. Copy Account SID and Auth Token from Twilio Dashboard
5. Set in config/settings.json:
   - twilio_account_sid: ACxxxxxx
   - twilio_auth_token: your_token
   - twilio_sms_number: +1234567890  (your Twilio number)

Note: This uses PLAIN SMS (not WhatsApp).
      WhatsApp is in channels/whatsapp_bot.py

⚕️ Medical Disclaimer: Medgent is a wellness assistant only.
   Always consult your doctor for medical advice.
"""

import asyncio, json, logging, sys
from pathlib import Path
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO, format='%(asctime)s [SMS] %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
bot = MedgentBot()
NEW_SESSIONS = set()


@app.route("/webhook/sms", methods=["POST"])
def sms_webhook():
    """Receive SMS messages via Twilio."""
    text   = request.values.get("Body", "").strip()
    sender = request.values.get("From", "")

    if not text or not sender:
        return str(MessagingResponse()), 200

    is_new = sender not in NEW_SESSIONS
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        response = loop.run_until_complete(
            bot.process_message(text, is_new_session=is_new)
        )
        NEW_SESSIONS.add(sender)
    except Exception as e:
        logger.error(f"SMS error: {e}")
        response = f"⚠️ Sorry, I had an error. Please try again.\n\n{DISCLAIMER}"
    finally:
        loop.close()

    # SMS has 160 char per segment — Twilio auto-concatenates up to ~1600 chars
    # Keep response under 1500 chars for SMS
    if len(response) > 1400:
        response = response[:1380] + "\n\n...Reply 'more' for the rest."

    resp = MessagingResponse()
    resp.message(response)
    return str(resp), 200


@app.route("/health", methods=["GET"])
def health():
    return {"status": "running", "channel": "sms"}, 200


if __name__ == "__main__":
    config = json.loads(Path("config/settings.json").read_text())
    if not config.get("twilio_account_sid"):
        print("❌ No Twilio credentials in config/settings.json")
        print("Sign up free at: https://twilio.com/try-twilio")
        sys.exit(1)
    logger.info("📱 Medgent SMS bot running on port 5003")
    logger.info(f"Set Twilio webhook to: https://YOUR-DOMAIN.com/webhook/sms")
    app.run(host="0.0.0.0", port=5003, debug=False)
