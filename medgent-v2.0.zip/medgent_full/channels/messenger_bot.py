"""
Medgent — Facebook Messenger Bot Channel
Connects Medgent to Facebook Messenger via Meta Graph API + Webhooks

HOW TO SET UP (15 minutes):
1. Go to https://developers.facebook.com → My Apps → Create App
2. Choose "Business" type → name it "Medgent Health Coach"
3. Add "Messenger" product to your app
4. Create a Facebook Page (or use existing one) — this is your bot's identity
5. In Messenger → Settings:
   - Generate Page Access Token → copy it
   - Set up Webhook URL: https://yourdomain.com/webhook/messenger
   - Verify Token: choose any string (e.g. "medgent_verify_2026")
   - Subscribe to: messages, messaging_postbacks
6. Set in config/settings.json:
   - fb_page_token: your Page Access Token
   - fb_verify_token: the string you chose above

⚕️ Medical Disclaimer: Medgent is a wellness assistant only.
   Always consult your doctor for medical advice.
"""

import asyncio, json, logging, sys, hmac, hashlib
from pathlib import Path
from flask import Flask, request, jsonify
import httpx

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO, format='%(asctime)s [Messenger] %(message)s')
logger = logging.getLogger(__name__)

config       = json.loads(Path("config/settings.json").read_text())
PAGE_TOKEN   = config.get("fb_page_token", "")
VERIFY_TOKEN = config.get("fb_verify_token", "medgent_verify_2026")
APP_SECRET   = config.get("fb_app_secret", "")

app = Flask(__name__)
bot = MedgentBot()
NEW_SESSIONS = set()


async def send_messenger(recipient_id: str, message: str):
    """Send a message via Facebook Messenger API."""
    # Split at 2000 chars (Messenger limit)
    chunks = [message[i:i+1900] for i in range(0, len(message), 1900)]
    async with httpx.AsyncClient(timeout=15) as client:
        for chunk in chunks:
            await client.post(
                "https://graph.facebook.com/v18.0/me/messages",
                params={"access_token": PAGE_TOKEN},
                json={"recipient": {"id": recipient_id}, "message": {"text": chunk}}
            )


@app.route("/webhook/messenger", methods=["GET"])
def messenger_verify():
    """Facebook webhook verification challenge."""
    mode  = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")
    if mode == "subscribe" and token == VERIFY_TOKEN:
        logger.info("✅ Messenger webhook verified!")
        return challenge, 200
    return "Forbidden", 403


@app.route("/webhook/messenger", methods=["POST"])
def messenger_webhook():
    """Receive messages from Facebook Messenger."""
    data = request.get_json()
    if data.get("object") != "page":
        return "OK", 200

    for entry in data.get("entry", []):
        for event in entry.get("messaging", []):
            sender_id = event.get("sender", {}).get("id", "")
            message   = event.get("message", {})
            text      = message.get("text", "").strip()

            if not text or not sender_id:
                continue

            is_new = sender_id not in NEW_SESSIONS
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                response = loop.run_until_complete(
                    bot.process_message(text, is_new_session=is_new)
                )
                NEW_SESSIONS.add(sender_id)
                loop.run_until_complete(send_messenger(sender_id, response))
            except Exception as e:
                logger.error(f"Messenger error: {e}")
                loop.run_until_complete(
                    send_messenger(sender_id,
                        "⚠️ I had trouble responding. Please try again.\n\n" + DISCLAIMER)
                )
            finally:
                loop.close()

    return "OK", 200


if __name__ == "__main__":
    if not PAGE_TOKEN:
        print("❌ No fb_page_token in config/settings.json")
        print("Get your token from: https://developers.facebook.com")
        sys.exit(1)
    logger.info("💙 Medgent Facebook Messenger bot running on port 5001")
    logger.info(f"Set webhook URL to: https://YOUR-DOMAIN.com/webhook/messenger")
    app.run(host="0.0.0.0", port=5001, debug=False)
