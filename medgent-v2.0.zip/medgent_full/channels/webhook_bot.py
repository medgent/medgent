"""
Medgent — Generic Webhook Bot (OpenClaw-compatible)
Works with ANY platform that supports webhooks:
WeChat, Line, Viber, Kik, Snapchat, or any custom integration.

HOW IT WORKS:
Any platform sends a POST request to:
  POST /webhook/generic
  Content-Type: application/json
  {
    "user_id": "unique_user_identifier",
    "message": "the text they sent",
    "platform": "wechat"  (optional label)
  }

Medgent responds with JSON:
  {
    "reply": "Medgent's response text",
    "platform": "wechat"
  }

CONNECTING WECHAT:
- WeChat Official Account Platform: mp.weixin.qq.com
- Set Server URL to: https://YOUR-DOMAIN.com/webhook/generic
- Token: medgent_wechat_2026
- Follow WeChat's developer docs for message format

CONNECTING LINE:
- LINE Developers Console: developers.line.biz
- Messaging API → Webhook URL: https://YOUR-DOMAIN.com/webhook/line
- The /webhook/line endpoint handles LINE's specific format

CONNECTING VIBER:
- Set webhook: https://chatapi.viber.com/pa/set_webhook
- URL: https://YOUR-DOMAIN.com/webhook/viber

⚕️ Medical Disclaimer: Medgent is a wellness assistant only.
   Always consult your doctor for medical advice.
"""

import asyncio, json, logging, sys, hashlib, hmac
from pathlib import Path
from flask import Flask, request, jsonify
import httpx

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO, format='%(asctime)s [Webhook] %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
bot = MedgentBot()
NEW_SESSIONS = set()
config = json.loads(Path("config/settings.json").read_text()) if Path("config/settings.json").exists() else {}


# ══════════════════════════════════
# GENERIC WEBHOOK — works with any platform
# ══════════════════════════════════
@app.route("/webhook/generic", methods=["POST"])
def generic_webhook():
    """
    Universal webhook endpoint.
    Any platform can POST to this endpoint with:
    { "user_id": "...", "message": "...", "platform": "wechat" }
    """
    data = request.get_json(silent=True) or {}
    user_id  = data.get("user_id", data.get("from", data.get("sender", "")))
    text     = data.get("message", data.get("text", data.get("body", ""))).strip()
    platform = data.get("platform", "generic")

    if not text or not user_id:
        return jsonify({"error": "Missing user_id or message"}), 400

    is_new = user_id not in NEW_SESSIONS
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        response = loop.run_until_complete(
            bot.process_message(text, is_new_session=is_new)
        )
        NEW_SESSIONS.add(user_id)
        logger.info(f"[{platform}] {user_id}: {text[:40]} → replied")
        return jsonify({"reply": response, "platform": platform, "user_id": user_id})
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return jsonify({"reply": f"⚠️ Error. Try again.\n{DISCLAIMER}", "platform": platform}), 500
    finally:
        loop.close()


# ══════════════════════════════════
# LINE SPECIFIC WEBHOOK
# ══════════════════════════════════
@app.route("/webhook/line", methods=["POST"])
def line_webhook():
    """LINE Messaging API webhook."""
    data     = request.get_json(silent=True) or {}
    line_token = config.get("line_channel_access_token", "")
    events   = data.get("events", [])

    for event in events:
        if event.get("type") != "message":
            continue
        text    = event.get("message", {}).get("text", "").strip()
        user_id = event.get("source", {}).get("userId", "")
        reply_token = event.get("replyToken", "")

        if not text or not user_id:
            continue

        is_new = user_id not in NEW_SESSIONS
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            response = loop.run_until_complete(
                bot.process_message(text, is_new_session=is_new)
            )
            NEW_SESSIONS.add(user_id)
            # Send reply via LINE API
            loop.run_until_complete(_send_line_reply(reply_token, response, line_token))
        except Exception as e:
            logger.error(f"LINE error: {e}")
        finally:
            loop.close()

    return jsonify({"status": "ok"})


async def _send_line_reply(reply_token: str, text: str, token: str):
    """Send a reply via LINE Messaging API."""
    # LINE has 5000 char limit per message
    chunks = [text[i:i+4900] for i in range(0, len(text), 4900)]
    messages = [{"type": "text", "text": chunk} for chunk in chunks[:5]]  # max 5 messages

    async with httpx.AsyncClient(timeout=15) as client:
        await client.post(
            "https://api.line.me/v2/bot/message/reply",
            headers={"Authorization": f"Bearer {token}"},
            json={"replyToken": reply_token, "messages": messages}
        )


# ══════════════════════════════════
# WECHAT SPECIFIC WEBHOOK
# ══════════════════════════════════
@app.route("/webhook/wechat", methods=["GET", "POST"])
def wechat_webhook():
    """WeChat Official Account webhook (simplified)."""
    if request.method == "GET":
        # WeChat server verification
        params = {k: request.args.get(k, '') for k in ['timestamp', 'nonce', 'signature']}
        token = config.get("wechat_token", "medgent_wechat_2026")
        check = sorted([token, params['timestamp'], params['nonce']])
        signature = hashlib.sha1(''.join(check).encode()).hexdigest()
        if signature == params.get('signature'):
            return request.args.get('echostr', '')
        return 'Invalid', 403

    # POST — incoming message
    # WeChat sends XML, parse it simply
    from xml.etree import ElementTree as ET
    try:
        tree = ET.fromstring(request.data)
        msg_type = tree.findtext('MsgType', '')
        content  = tree.findtext('Content', '').strip()
        from_user = tree.findtext('FromUserName', '')
        to_user   = tree.findtext('ToUserName', '')

        if msg_type != 'text' or not content:
            return 'success'

        is_new = from_user not in NEW_SESSIONS
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        response = loop.run_until_complete(bot.process_message(content, is_new_session=is_new))
        loop.close()
        NEW_SESSIONS.add(from_user)

        import time
        return f"""<xml>
<ToUserName><![CDATA[{from_user}]]></ToUserName>
<FromUserName><![CDATA[{to_user}]]></FromUserName>
<CreateTime>{int(time.time())}</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[{response[:2000]}]]></Content>
</xml>""", 200, {'Content-Type': 'application/xml'}

    except Exception as e:
        logger.error(f"WeChat error: {e}")
        return 'success'


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "running", "channels": ["generic", "line", "wechat"]}), 200


if __name__ == "__main__":
    logger.info("🔗 Medgent Generic Webhook server running on port 5004")
    logger.info("Endpoints:")
    logger.info("  POST /webhook/generic  — Any platform")
    logger.info("  POST /webhook/line     — LINE Messenger")
    logger.info("  POST /webhook/wechat   — WeChat Official Account")
    app.run(host="0.0.0.0", port=5004, debug=False)
