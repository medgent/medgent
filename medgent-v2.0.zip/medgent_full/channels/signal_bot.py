"""
Medgent — Signal Bot Channel
Connects Medgent to Signal via signal-cli REST API
https://github.com/bbernhard/signal-cli-rest-api

HOW TO SET UP:
1. Install signal-cli-rest-api (Docker is easiest):
   docker run -d --name signal-api -p 8080:8080 \
     -v /tmp/signal-cli-config:/home/.local/share/signal-cli \
     -e 'MODE=native' \
     bbernhard/signal-cli-rest-api

2. Register your phone number:
   curl -X POST http://localhost:8080/v1/register/+YOUR_PHONE_NUMBER

3. Verify the OTP code Signal sends to your phone:
   curl -X POST http://localhost:8080/v1/register/+YOUR_PHONE_NUMBER/verify/OTP_CODE

4. Set SIGNAL_NUMBER in config/settings.json

⚕️ Medical Disclaimer: Medgent is a wellness assistant only.
   Always consult your doctor for medical advice.
"""

import asyncio, json, logging, time, sys
from pathlib import Path
import httpx

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO, format='%(asctime)s [Signal] %(message)s')
logger = logging.getLogger(__name__)

config = json.loads(Path("config/settings.json").read_text())
SIGNAL_API  = config.get("signal_api_url", "http://localhost:8080")
MY_NUMBER   = config.get("signal_number", "")   # e.g. +1234567890

bot = MedgentBot()
NEW_SESSIONS = set()
last_timestamps = {}   # track seen messages to avoid duplicates


async def send_signal(recipient: str, message: str):
    """Send a Signal message."""
    async with httpx.AsyncClient(timeout=15) as client:
        await client.post(
            f"{SIGNAL_API}/v2/send",
            json={"message": message, "number": MY_NUMBER, "recipients": [recipient]}
        )


async def receive_messages():
    """Poll for new Signal messages."""
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(f"{SIGNAL_API}/v1/receive/{MY_NUMBER}")
        return r.json() if r.status_code == 200 else []


async def process_signal_messages():
    """Main polling loop for Signal messages."""
    logger.info(f"🔵 Medgent Signal bot running for {MY_NUMBER}")
    logger.info("Send a message to your Signal number to start!")

    while True:
        try:
            messages = await receive_messages()
            for envelope in messages:
                msg_data = envelope.get("envelope", {})
                data_msg = msg_data.get("dataMessage", {})
                text = data_msg.get("message", "").strip()
                sender = msg_data.get("source", "")
                ts = data_msg.get("timestamp", 0)

                if not text or not sender:
                    continue
                # Skip already-processed messages
                if last_timestamps.get(sender) == ts:
                    continue
                last_timestamps[sender] = ts

                is_new = sender not in NEW_SESSIONS
                logger.info(f"Message from {sender}: {text[:50]}")

                # Show typing indicator
                async with httpx.AsyncClient() as c:
                    await c.put(f"{SIGNAL_API}/v1/typing-indicator/{MY_NUMBER}",
                                json={"recipient": sender})

                response = await bot.process_message(text, is_new_session=is_new)
                NEW_SESSIONS.add(sender)

                # Split long messages (Signal has ~4000 char limit)
                chunks = [response[i:i+3500] for i in range(0, len(response), 3500)]
                for chunk in chunks:
                    await send_signal(sender, chunk)
                    if len(chunks) > 1:
                        await asyncio.sleep(0.5)

        except Exception as e:
            logger.error(f"Signal error: {e}")

        await asyncio.sleep(2)  # Poll every 2 seconds


if __name__ == "__main__":
    if not MY_NUMBER:
        print("❌ No signal_number in config/settings.json")
        print("Run python setup.py first to configure Signal")
        sys.exit(1)
    asyncio.run(process_signal_messages())
