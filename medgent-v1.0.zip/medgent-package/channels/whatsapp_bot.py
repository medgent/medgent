"""
Medgent — WhatsApp Channel via Twilio
Flask webhook server that receives WhatsApp messages
and routes them through the Medgent agent.
"""

import asyncio, json, logging
from pathlib import Path
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from apscheduler.schedulers.background import BackgroundScheduler
from twilio.rest import Client
import sys; sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

app = Flask(__name__)
bot = MedgentBot()
scheduler = BackgroundScheduler()
NEW_SESSIONS = set()

config = json.loads(Path("config/settings.json").read_text())
twilio_sid = config.get("twilio_account_sid", "")
twilio_token = config.get("twilio_auth_token", "")
twilio_number = config.get("twilio_whatsapp_number", "")
your_number = config.get("your_whatsapp_number", "")
twilio_client = Client(twilio_sid, twilio_token) if twilio_sid else None


@app.route("/webhook/whatsapp", methods=["POST"])
def whatsapp_webhook():
    incoming = request.values.get("Body", "").strip()
    sender = request.values.get("From", "")
    is_new = sender not in NEW_SESSIONS

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        response_text = loop.run_until_complete(
            bot.process_message(incoming, is_new_session=is_new)
        )
    except Exception as e:
        response_text = f"⚠️ Sorry, I had an error: {str(e)[:100]}\n\n{DISCLAIMER}"
    finally:
        loop.close()

    NEW_SESSIONS.add(sender)
    resp = MessagingResponse()
    # WhatsApp has ~1600 char limit per message
    if len(response_text) > 1500:
        parts = [response_text[i:i+1500] for i in range(0, len(response_text), 1500)]
        for part in parts:
            resp.message(part)
    else:
        resp.message(response_text)
    return str(resp)


def send_whatsapp(to: str, message: str):
    """Send a proactive WhatsApp message."""
    if not twilio_client:
        print("⚠️ Twilio not configured — cannot send proactive messages")
        return
    try:
        twilio_client.messages.create(body=message, from_=twilio_number, to=to)
        print(f"✅ Sent to {to}")
    except Exception as e:
        print(f"❌ Failed to send: {e}")


def send_morning_briefing():
    """Scheduled job: send morning health briefing."""
    profile = bot.user_profile
    name = profile.get("name", "there").split()[0]
    meds = profile.get("medications", "your medications")
    cal = profile.get("calorie_goal", 2000)
    message = (
        f"🌅 *Good morning, {name}!* Here's your daily health briefing:\n\n"
        f"💊 Medications: Take *{meds}* with breakfast\n"
        f"💧 Water goal: 8 glasses (2.5L) today\n"
        f"🔥 Calorie goal: {cal} kcal\n"
        f"🏋️ Tip: A 20-min walk after meals helps manage blood sugar\n\n"
        f"Have a great, healthy day! 💚\n\n{DISCLAIMER}"
    )
    send_whatsapp(your_number, message)


def send_weekly_report():
    """Scheduled job: send weekly health summary on Sundays."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    report = loop.run_until_complete(bot._generate_weekly_report())
    loop.close()
    send_whatsapp(your_number, "📋 " + report)


# Schedule proactive agents
morning_time = config.get("morning_briefing_time", "07:30").split(":")
scheduler.add_job(send_morning_briefing, "cron",
                  hour=int(morning_time[0]), minute=int(morning_time[1]),
                  id="morning_briefing")
scheduler.add_job(send_weekly_report, "cron",
                  day_of_week="sun", hour=9, minute=0,
                  id="weekly_report")
scheduler.start()


if __name__ == "__main__":
    print("🟢 Medgent WhatsApp server running on port 5000")
    print(f"📡 Webhook URL: http://YOUR-IP:5000/webhook/whatsapp")
    print("Configure this URL in your Twilio console.")
    app.run(host="0.0.0.0", port=5000, debug=False)
