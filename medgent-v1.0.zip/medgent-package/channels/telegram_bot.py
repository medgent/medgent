"""
Medgent — Telegram Bot Channel
Connects Medgent agent to Telegram via python-telegram-bot
"""

import asyncio, logging, json
from pathlib import Path
from telegram import Update
from telegram.ext import Application, MessageHandler, CommandHandler, filters, ContextTypes
import sys; sys.path.insert(0, str(Path(__file__).parent.parent))
from core.medgent import MedgentBot, DISCLAIMER

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = MedgentBot()
NEW_SESSIONS = set()   # track new users this run

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    name = update.effective_user.first_name or "there"
    uid = update.effective_user.id
    NEW_SESSIONS.add(uid)
    await update.message.reply_text(
        f"👋 Hello *{name}*! I'm *Medgent* — your personal AI health manager.\n\n"
        f"{DISCLAIMER}\n\n"
        f"To get started, use /setup to configure your health profile.\n\n"
        f"Or just message me anything — ask about your diet, medications, workouts, and more!",
        parse_mode="Markdown"
    )

async def setup(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👤 *Let's set up your health profile!*\n\n"
        "Please send me this information:\n\n"
        "Name, Age, Condition, Height(cm), Weight(kg), Medications, Diet restrictions, Goal\n\n"
        "*Example:*\n"
        "Name: Sarah | Age: 42 | Condition: Type 2 Diabetes | Height: 165 | "
        "Weight: 78 | Medications: Metformin 500mg | Diet: Low sugar | Goal: Lose 8kg",
        parse_mode="Markdown"
    )

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    text = update.message.text or ""
    is_new = uid in NEW_SESSIONS
    if is_new:
        NEW_SESSIONS.discard(uid)

    # Show "typing..."
    await ctx.bot.send_chat_action(update.effective_chat.id, "typing")

    try:
        response = await bot.process_message(text, is_new_session=is_new)
        # Split long messages for Telegram (4096 char limit)
        for chunk in [response[i:i+4000] for i in range(0, len(response), 4000)]:
            await update.message.reply_text(chunk, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error: {e}")
        await update.message.reply_text(
            "⚠️ I had trouble processing that. Please try again.\n\n"
            "If the issue persists, check your AI API key in config/settings.json"
        )

async def status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    p = bot.user_profile
    bmi = "Not logged yet"
    row = bot.db.execute("SELECT bmi, date FROM bmi_log ORDER BY id DESC LIMIT 1").fetchone()
    if row:
        bmi = f"{row[0]} ({row[1]})"
    await update.message.reply_text(
        f"📊 *Medgent Status*\n\n"
        f"👤 {p.get('name','Not set')} · {p.get('condition','No condition set')}\n"
        f"⚖️ Latest BMI: {bmi}\n"
        f"🤖 AI Provider: {bot.ai_provider.upper()}\n"
        f"✅ Bot is running!\n\n"
        f"{DISCLAIMER}",
        parse_mode="Markdown"
    )

def run():
    config = json.loads(Path("config/settings.json").read_text())
    token = config.get("telegram_token", "")
    if not token:
        print("❌ No Telegram token found. Run python setup.py first.")
        return

    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("setup", setup))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🤖 Medgent Telegram bot is running...")
    print("Send /start to your bot on Telegram to begin!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    run()
