# 🏥 Medgent — Personal AI Health Manager

> **Open Source · Free · Works in WhatsApp & Telegram · Powered by Claude, ChatGPT, Gemini & more**

Medgent is a free, open-source AI health agent that manages your health via the chat apps you already use. Set it up once — it sends you daily meal plans, medication reminders, BMI updates, workout plans, weekly reports, and answers all your health questions 24/7.

---

## ⬇️ Download & Install (3 ways)

### Way 1 — One-click on a server (Recommended for 24/7 use)
```bash
curl -fsSL https://raw.githubusercontent.com/medgent/medgent/main/scripts/install.sh | bash
cd medgent && python3 setup.py
```

### Way 2 — Download ZIP (No terminal needed)
👉 **[Click here to download Medgent.zip](https://github.com/medgent/medgent/archive/main.zip)**

Then unzip it, open a terminal in the folder, and run:
```bash
pip install -r requirements.txt
python setup.py
```

### Way 3 — Clone with Git
```bash
git clone https://github.com/medgent/medgent.git
cd medgent
pip install -r requirements.txt
python setup.py
```

---

## 🚀 Quick Start (5 minutes)

The setup wizard guides you through everything — no coding needed:

```
1. python setup.py        ← answers 8 simple questions
2. bash scripts/start.sh  ← starts Medgent
3. Message your bot!      ← it's live
```

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🥗 Meal Planner | Daily personalised meal plans for your condition |
| ⚖️ BMI Tracker | Log weight, track trends, get AI tips |
| 💊 Medication Reminders | Timely WhatsApp/Telegram alerts |
| 🏋️ Workout Planner | Condition-safe exercise routines |
| 📅 Health Calendar | Book and track appointments |
| 📋 Weekly Reports | Automated Sunday health summaries |
| 🌅 Morning Briefings | Daily health briefing at 7:30 AM |
| 🧠 Symptom Journal | Log & track symptoms over time |
| 🤖 Custom Agents | Build your own health automation |

---

## 🤖 Supported AI Providers

| Provider | Cost | Free Tier |
|----------|------|-----------|
| Claude (Anthropic) | ~$0.003/msg | ✅ $5 free credit |
| ChatGPT (OpenAI) | ~$0.002/msg | ✅ Free trial |
| Gemini (Google) | Free–low cost | ✅ Free tier |
| Mistral AI | Low cost | ✅ Free tier |
| Llama (Local) | **FREE** | ✅ 100% offline |
| DeepSeek | Very low | ✅ Free tier |

---

## 💬 Supported Chat Channels

- 📱 **WhatsApp** (via Twilio — free trial)
- ✈️ **Telegram** (free Bot API — easiest!)
- 🔵 **Signal** (via signal-cli)
- 💬 **SMS** (via Twilio)
- 🌐 **Web browser** (no setup needed)

---

## 🖥️ Server Options (Free!)

| Option | Cost | Notes |
|--------|------|-------|
| Oracle Cloud Free Tier | **FREE forever** | 4 CPUs, 24GB RAM |
| Hetzner VPS | €3.29/month | Best value in Europe |
| DigitalOcean | $4/month | Beginner friendly |
| Hostinger VPS | $4.99/month | Good support |
| Your own computer | **FREE** | Not 24/7 |

---

## ⚕️ Medical Disclaimer

> Medgent is a **wellness assistant only** — not a substitute for professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare provider before making changes to medications, diet, or exercise. Medgent never diagnoses conditions. In emergencies, call **112** or **911** immediately.

---

## 🔒 Privacy & Security

- ✅ **Zero servers** — your data stays on your device/VPS
- ✅ **Your API key** is stored locally only, never transmitted to Medgent
- ✅ **No tracking**, no analytics, no ads
- ✅ **Open source** — audit every line of code
- ✅ Health data stored in local SQLite database only

---

## 🛠️ Project Structure

```
medgent/
├── setup.py              ← Setup wizard (start here!)
├── requirements.txt      ← Python dependencies
├── core/
│   └── medgent.py        ← Main agent engine
├── channels/
│   ├── telegram_bot.py   ← Telegram integration
│   └── whatsapp_bot.py   ← WhatsApp/Twilio integration
├── agents/               ← Pre-built health agents
├── config/
│   └── settings.json     ← Your config (auto-created by setup)
├── data/
│   └── medgent.db        ← Your health data (SQLite)
├── scripts/
│   ├── install.sh        ← One-click installer
│   └── start.sh          ← Start all services
└── docs/                 ← Documentation
```

---

## 📄 Licence

MIT — free to use, modify, and distribute.

---

## 🤝 Contributing

Pull requests welcome! See CONTRIBUTING.md for guidelines.

Built with ❤️ for people managing their health.
