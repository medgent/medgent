"""
Medgent — Personal AI Health Manager
Core Agent Engine
Open Source · MIT Licence · github.com/medgent/medgent
"""

import os, json, sqlite3, datetime, re
from pathlib import Path

DISCLAIMER = (
    "⚕️ *Medical Disclaimer:* Medgent is a wellness assistant only — "
    "not a substitute for medical advice. Always consult your doctor "
    "before changing medications or diet. Not for emergencies — call 112/911."
)

SYSTEM_PROMPT = """You are Medgent — a compassionate, knowledgeable personal AI health manager.

USER PROFILE:
{profile}

YOUR RULES (ALWAYS FOLLOW):
1. Tailor ALL advice to the user's specific health condition
2. Be warm, encouraging, and non-judgmental
3. NEVER diagnose conditions — you are a wellness ASSISTANT only
4. Add ⚕️ disclaimer when giving specific health advice
5. Recommend consulting their doctor for any medical decisions
6. Use emojis tastefully for WhatsApp/Telegram readability
7. Keep responses practical and actionable
8. For medication questions always say "as prescribed by your doctor"

AVAILABLE SKILLS:
- meal_plan: Generate personalised meal plans
- bmi_calc: Calculate and log BMI
- workout: Suggest safe exercises
- reminder: Schedule medication/health reminders
- log_symptom: Log symptoms to journal
- weekly_report: Generate weekly health summary
- lab_explain: Explain lab results in plain English
- appointment: Manage health calendar
"""

class MedgentBot:
    def __init__(self, config_path="config/settings.json"):
        self.config = self._load_config(config_path)
        self.db = self._init_db()
        self.api_key = self.config.get("api_key", "")
        self.ai_provider = self.config.get("ai_provider", "claude")
        self.user_profile = self.config.get("user_profile", {})

    def _load_config(self, path):
        if Path(path).exists():
            with open(path) as f:
                return json.load(f)
        return {}

    def _init_db(self):
        db = sqlite3.connect("data/medgent.db", check_same_thread=False)
        db.execute("""CREATE TABLE IF NOT EXISTS messages
            (id INTEGER PRIMARY KEY, role TEXT, content TEXT, ts TEXT)""")
        db.execute("""CREATE TABLE IF NOT EXISTS bmi_log
            (id INTEGER PRIMARY KEY, weight REAL, height REAL, bmi REAL, date TEXT)""")
        db.execute("""CREATE TABLE IF NOT EXISTS med_log
            (id INTEGER PRIMARY KEY, med TEXT, taken INTEGER, scheduled TEXT, ts TEXT)""")
        db.execute("""CREATE TABLE IF NOT EXISTS workout_log
            (id INTEGER PRIMARY KEY, type TEXT, duration INTEGER, intensity TEXT, ts TEXT)""")
        db.execute("""CREATE TABLE IF NOT EXISTS symptom_log
            (id INTEGER PRIMARY KEY, symptom TEXT, severity INTEGER, ts TEXT)""")
        db.commit()
        return db

    def should_show_disclaimer(self, message: str, context: str = "") -> bool:
        """Show disclaimer when health advice is given or at session start."""
        health_keywords = [
            "medication","medicine","dose","drug","symptom","pain","eat","diet",
            "exercise","workout","blood","sugar","pressure","weight","bmi",
            "calories","treatment","heal","condition","diabetes","hypertension"
        ]
        text = (message + context).lower()
        return any(kw in text for kw in health_keywords)

    def build_profile_string(self) -> str:
        p = self.user_profile
        return (
            f"Name: {p.get('name','User')} | Age: {p.get('age','?')} | "
            f"Gender: {p.get('gender','?')}\n"
            f"Condition: {p.get('condition','Not specified')}\n"
            f"Height: {p.get('height','?')}cm | Weight: {p.get('weight','?')}kg\n"
            f"Medications: {p.get('medications','None')}\n"
            f"Diet restrictions: {p.get('diet_restrictions','None')}\n"
            f"Calorie goal: {p.get('calorie_goal',2000)} kcal/day\n"
            f"Health goal: {p.get('health_goal','General wellness')}"
        )

    def get_history(self, limit=10):
        rows = self.db.execute(
            "SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [{"role": r[0], "content": r[1]} for r in reversed(rows)]

    def save_message(self, role: str, content: str):
        ts = datetime.datetime.now().isoformat()
        self.db.execute(
            "INSERT INTO messages (role, content, ts) VALUES (?,?,?)",
            (role, content, ts)
        )
        self.db.commit()

    async def call_ai(self, user_message: str) -> str:
        """Call the configured AI provider."""
        history = self.get_history()
        history.append({"role": "user", "content": user_message})
        system = SYSTEM_PROMPT.format(profile=self.build_profile_string())

        if self.ai_provider == "claude":
            return await self._call_claude(system, history)
        elif self.ai_provider == "openai":
            return await self._call_openai(system, history)
        elif self.ai_provider == "gemini":
            return await self._call_gemini(system, history)
        elif self.ai_provider == "mistral":
            return await self._call_mistral(system, history)
        else:
            return await self._call_claude(system, history)

    async def _call_claude(self, system: str, messages: list) -> str:
        import httpx
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"Content-Type": "application/json"},
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 600,
                    "system": system,
                    "messages": messages
                }
            )
            data = r.json()
            return data["content"][0]["text"]

    async def _call_openai(self, system: str, messages: list) -> str:
        import httpx
        msgs = [{"role": "system", "content": system}] + messages
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": "gpt-4o-mini", "max_tokens": 600, "messages": msgs}
            )
            return r.json()["choices"][0]["message"]["content"]

    async def _call_gemini(self, system: str, messages: list) -> str:
        import httpx
        contents = [{"role": "user" if m["role"]=="user" else "model",
                     "parts": [{"text": m["content"]}]} for m in messages]
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"gemini-1.5-flash:generateContent?key={self.api_key}",
                json={"contents": contents,
                      "systemInstruction": {"parts": [{"text": system}]}}
            )
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]

    async def _call_mistral(self, system: str, messages: list) -> str:
        import httpx
        msgs = [{"role": "system", "content": system}] + messages
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                "https://api.mistral.ai/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": "mistral-small", "max_tokens": 600, "messages": msgs}
            )
            return r.json()["choices"][0]["message"]["content"]

    async def process_message(self, user_message: str, is_new_session: bool = False) -> str:
        """Main message handler — the agent brain."""
        self.save_message("user", user_message)
        msg_lower = user_message.lower()

        # Handle special commands
        if any(x in msg_lower for x in ["✓ taken", "took my", "medication taken", "took metformin"]):
            return self._log_medication(user_message)
        if re.search(r"weigh(ed|t)?\s+(\d+\.?\d*)\s*kg", msg_lower):
            kg = float(re.search(r"(\d+\.?\d*)\s*kg", msg_lower).group(1))
            return self._log_weight(kg)
        if "workout done" in msg_lower or "exercise done" in msg_lower:
            return self._log_workout(user_message)
        if "weekly report" in msg_lower:
            return await self._generate_weekly_report()

        # Call AI for everything else
        response = await self.call_ai(user_message)

        # Add disclaimer if health-related
        if self.should_show_disclaimer(user_message, response):
            response += f"\n\n{DISCLAIMER}"

        # Add disclaimer at new session start
        if is_new_session:
            response = DISCLAIMER + "\n\n" + response

        self.save_message("assistant", response)
        return response

    def _log_medication(self, msg: str) -> str:
        ts = datetime.datetime.now().isoformat()
        med = self.user_profile.get("medications", "medication").split(",")[0].strip()
        self.db.execute(
            "INSERT INTO med_log (med, taken, scheduled, ts) VALUES (?,1,?,?)",
            (med, ts, ts)
        )
        self.db.commit()
        return (f"✅ Logged! *{med}* marked as taken at "
                f"{datetime.datetime.now().strftime('%H:%M')}.\n\n"
                f"Keep it up — consistency is key to managing your condition! 💊\n\n"
                f"{DISCLAIMER}")

    def _log_weight(self, kg: float) -> str:
        h = self.user_profile.get("height", 170)
        bmi = round(kg / ((h / 100) ** 2), 1)
        cat = ("Underweight" if bmi < 18.5 else
               "Healthy" if bmi < 25 else
               "Overweight" if bmi < 30 else "Obese")
        ts = datetime.date.today().isoformat()
        self.db.execute(
            "INSERT INTO bmi_log (weight, height, bmi, date) VALUES (?,?,?,?)",
            (kg, h, bmi, ts)
        )
        self.db.commit()
        last = self.db.execute(
            "SELECT weight FROM bmi_log ORDER BY id DESC LIMIT 1 OFFSET 1"
        ).fetchone()
        change = f" (↓{round(last[0]-kg,1)}kg from last time 🎉)" if last and last[0] > kg else ""
        return (f"⚖️ *BMI Updated!*\n\nWeight: *{kg}kg*{change}\n"
                f"BMI: *{bmi}* — {cat}\nGoal: {self.user_profile.get('goal_weight','?')}kg\n\n"
                f"{DISCLAIMER}")

    def _log_workout(self, msg: str) -> str:
        ts = datetime.datetime.now().isoformat()
        self.db.execute(
            "INSERT INTO workout_log (type, duration, intensity, ts) VALUES (?,30,'moderate',?)",
            ("General exercise", ts)
        )
        self.db.commit()
        return (f"💪 Workout logged! Great work today!\n\n"
                f"Regular exercise is one of the best things for managing your condition. "
                f"Keep it up! 🌟\n\n{DISCLAIMER}")

    async def _generate_weekly_report(self) -> str:
        bmi_rows = self.db.execute(
            "SELECT weight, bmi, date FROM bmi_log ORDER BY id DESC LIMIT 4"
        ).fetchall()
        med_rows = self.db.execute(
            "SELECT COUNT(*) FROM med_log WHERE taken=1 AND ts > datetime('now','-7 days')"
        ).fetchone()
        wk_rows = self.db.execute(
            "SELECT COUNT(*) FROM workout_log WHERE ts > datetime('now','-7 days')"
        ).fetchone()
        bmi_summary = ", ".join([f"{r[1]} ({r[2]})" for r in bmi_rows]) if bmi_rows else "No data"
        prompt = (
            f"Generate a warm, encouraging weekly health report for "
            f"{self.user_profile.get('name','the user')} with "
            f"{self.user_profile.get('condition','their condition')}.\n"
            f"BMI logs this week: {bmi_summary}\n"
            f"Medications taken: {med_rows[0] if med_rows else 0} doses\n"
            f"Workouts: {wk_rows[0] if wk_rows else 0} sessions\n"
            f"Include: summary, wins, 3 goals for next week, doctor visit checklist."
        )
        report = await self.call_ai(prompt)
        return f"📋 *Weekly Health Report*\n\n{report}\n\n{DISCLAIMER}"
