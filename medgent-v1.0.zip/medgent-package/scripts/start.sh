#!/bin/bash
# Medgent — Start Script
# Keeps Medgent running 24/7 using screen sessions

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   🏥 Starting Medgent...             ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
echo ""

# Check config exists
if [ ! -f "config/settings.json" ]; then
  echo -e "${RED}❌ No config found. Run: python setup.py first${NC}"
  exit 1
fi

# Read channel from config
CHANNEL=$(python3 -c "import json; c=json.load(open('config/settings.json')); print(c.get('channel','telegram'))" 2>/dev/null)
echo -e "${GREEN}✓ Channel: ${YELLOW}$CHANNEL${NC}"

# Install screen if not present
if ! command -v screen &> /dev/null; then
  echo "Installing screen..."
  apt-get install -y screen 2>/dev/null || yum install -y screen 2>/dev/null
fi

# Kill existing sessions
screen -S medgent-telegram -X quit 2>/dev/null
screen -S medgent-whatsapp -X quit 2>/dev/null

# Start appropriate channels
if [ "$CHANNEL" = "telegram" ] || [ "$CHANNEL" = "both" ]; then
  echo -e "${GREEN}🚀 Starting Telegram bot...${NC}"
  screen -dmS medgent-telegram bash -c "cd $(pwd) && python3 channels/telegram_bot.py 2>&1 | tee logs/telegram.log"
  echo -e "${GREEN}✅ Telegram bot running in background (screen: medgent-telegram)${NC}"
fi

if [ "$CHANNEL" = "whatsapp" ] || [ "$CHANNEL" = "both" ]; then
  echo -e "${GREEN}🚀 Starting WhatsApp webhook server...${NC}"
  screen -dmS medgent-whatsapp bash -c "cd $(pwd) && python3 channels/whatsapp_bot.py 2>&1 | tee logs/whatsapp.log"
  echo -e "${GREEN}✅ WhatsApp server running on port 5000 (screen: medgent-whatsapp)${NC}"
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ✅ Medgent is running!                      ║${NC}"
echo -e "${GREEN}║                                              ║${NC}"
echo -e "${GREEN}║  To see logs:                                ║${NC}"
echo -e "${GREEN}║    screen -r medgent-telegram                ║${NC}"
echo -e "${GREEN}║    screen -r medgent-whatsapp                ║${NC}"
echo -e "${GREEN}║                                              ║${NC}"
echo -e "${GREEN}║  To stop:  bash scripts/stop.sh              ║${NC}"
echo -e "${GREEN}║  To update: bash scripts/update.sh           ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
