#!/bin/bash
# Medgent One-Click Installer
# Usage: curl -fsSL https://raw.githubusercontent.com/medgent/medgent/main/install.sh | bash

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

clear
echo ""
echo -e "${GREEN}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║   🏥  MEDGENT INSTALLER                  ║"
echo "  ║   Personal AI Health Manager             ║"
echo "  ║   Open Source · Free · MIT Licence       ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  This will install Medgent on your system."
echo -e "  Takes about 2 minutes.\n"

# ── Check OS ──────────────────────────────────────
if command -v apt-get &> /dev/null; then
  PKG_MGR="apt-get"
  INSTALL="apt-get install -y -q"
elif command -v yum &> /dev/null; then
  PKG_MGR="yum"
  INSTALL="yum install -y -q"
elif command -v brew &> /dev/null; then
  PKG_MGR="brew"
  INSTALL="brew install"
else
  echo -e "${RED}❌ Could not detect package manager. Install Python 3.11+ manually.${NC}"
fi

# ── Install Python if needed ───────────────────────
echo -e "  ${YELLOW}[1/5]${NC} Checking Python..."
if ! command -v python3 &> /dev/null; then
  echo -e "  Installing Python 3..."
  $INSTALL python3 python3-pip python3-venv 2>/dev/null
fi
PYTHON_VER=$(python3 --version 2>&1 | grep -oP '\d+\.\d+')
echo -e "  ${GREEN}✓ Python $PYTHON_VER found${NC}"

# ── Install Git ───────────────────────────────────
echo -e "  ${YELLOW}[2/5]${NC} Checking Git..."
if ! command -v git &> /dev/null; then
  $INSTALL git 2>/dev/null
fi
echo -e "  ${GREEN}✓ Git ready${NC}"

# ── Clone Medgent ─────────────────────────────────
echo -e "  ${YELLOW}[3/5]${NC} Downloading Medgent..."
if [ -d "medgent" ]; then
  echo -e "  ${CYAN}Medgent folder exists — pulling latest version...${NC}"
  cd medgent && git pull --quiet && cd ..
else
  git clone --quiet https://github.com/medgent/medgent.git 2>/dev/null || {
    # Fallback: download zip if git fails
    echo -e "  ${CYAN}Downloading zip package instead...${NC}"
    curl -fsSL https://github.com/medgent/medgent/archive/main.zip -o medgent.zip
    unzip -q medgent.zip && mv medgent-main medgent && rm medgent.zip
  }
fi
cd medgent
echo -e "  ${GREEN}✓ Medgent downloaded${NC}"

# ── Create directories ────────────────────────────
mkdir -p config data logs

# ── Install Python deps ───────────────────────────
echo -e "  ${YELLOW}[4/5]${NC} Installing dependencies..."
python3 -m pip install -q -r requirements.txt 2>/dev/null
echo -e "  ${GREEN}✓ Dependencies installed${NC}"

# ── Make scripts executable ───────────────────────
chmod +x scripts/*.sh 2>/dev/null

# ── Done ──────────────────────────────────────────
echo -e "  ${YELLOW}[5/5]${NC} Installation complete!"
echo ""
echo -e "${GREEN}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║   ✅ Medgent installed successfully!     ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  ${BOLD}Now run the setup wizard:${NC}"
echo -e "  ${CYAN}cd medgent && python3 setup.py${NC}"
echo ""
echo -e "  It will guide you through:"
echo -e "  • Choosing your AI (Claude, ChatGPT, Gemini, etc.)"
echo -e "  • Connecting WhatsApp or Telegram"
echo -e "  • Setting your health profile"
echo -e "  • Scheduling your daily reminders"
echo ""
echo -e "  ${YELLOW}⚕️  Medgent is a wellness assistant only.${NC}"
echo -e "  ${YELLOW}   Always consult your doctor for medical advice.${NC}"
echo ""
